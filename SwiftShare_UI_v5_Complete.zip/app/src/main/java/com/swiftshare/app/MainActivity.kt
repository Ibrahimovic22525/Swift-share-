package com.swiftshare.app

import android.Manifest
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.nearby.connection.*
import java.nio.charset.StandardCharsets
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private val blue = Color.rgb(23,105,255)
    private val green = Color.rgb(28,185,111)
    private val bg = Color.rgb(247,249,252)
    private val serviceId = "com.swiftshare.app"
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private val endpoints = linkedMapOf<String,String>()
    private val selectedUris = mutableListOf<Uri>()
    private var connectedEndpoint: String? = null
    private var selectedScreen = "home"

    private val lifecycle = object: ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id:String, info:ConnectionInfo) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Connect to ${info.endpointName}?")
                .setMessage("Confirm this code on both phones:\n${info.authenticationDigits}")
                .setPositiveButton("Accept"){_,_-> Nearby.getConnectionsClient(this@MainActivity).acceptConnection(id,payload)}
                .setNegativeButton("Reject"){_,_-> Nearby.getConnectionsClient(this@MainActivity).rejectConnection(id)}
                .show()
        }
        override fun onConnectionResult(id:String, result:ConnectionResolution) {
            if(result.status.isSuccess){ connectedEndpoint=id; toast("Connected ✓"); if(selectedUris.isNotEmpty()) sendFiles() }
            else toast("Connection failed")
        }
        override fun onDisconnected(id:String){ if(connectedEndpoint==id) connectedEndpoint=null; toast("Device disconnected") }
    }
    private val payload = object: PayloadCallback() {
        override fun onPayloadReceived(id:String,p:Payload) { if(p.type==Payload.Type.BYTES) toast("Receiving ${String(p.asBytes(),StandardCharsets.UTF_8)}…") }
        override fun onPayloadTransferUpdate(id:String,u:PayloadTransferUpdate) {
            if(u.status==PayloadTransferUpdate.Status.SUCCESS) toast("Transfer complete ✓")
            else if(u.status==PayloadTransferUpdate.Status.ERROR) toast("Transfer failed")
        }
    }
    private val discovery = object: EndpointDiscoveryCallback() {
        override fun onEndpointFound(id:String, info:DiscoveredEndpointInfo){ endpoints[id]=info.endpointName; if(selectedScreen=="receive") showReceive() }
        override fun onEndpointLost(id:String){ endpoints.remove(id) }
    }

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        MobileAds.initialize(this){}
        requestPermissions()
        buildShell()
        showScreen("home")
    }

    private fun buildShell(){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        content=FrameLayout(this)
        root.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setBackgroundColor(Color.WHITE);setPadding(6,8,6,8)}
        val items=listOf("Home" to "⌂","Files" to "▣","History" to "◷","Settings" to "⚙")
        items.forEach{(label,icon)->
            val b=Button(this).apply{
                text="$icon\n$label";textSize=11f;setTextColor(Color.DKGRAY);setAllCaps(false)
                setBackgroundColor(Color.TRANSPARENT);setOnClickListener{showScreen(label.lowercase())}
            }
            nav.addView(b,LinearLayout.LayoutParams(0,64,1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showScreen(s:String){ selectedScreen=s; when(s){
        "home"->showHome();"files"->showFiles();"history"->showHistory();"settings"->showSettings();else->showHome()
    }}

    private fun base(title:String, back:Boolean=true):LinearLayout{
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,18,20,12);setBackgroundColor(bg)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        if(back){ val x=Button(this).apply{text="‹";textSize=30f;setBackgroundColor(Color.TRANSPARENT);setOnClickListener{showScreen("home")}};head.addView(x,LinearLayout.LayoutParams(52,60))}
        val t=TextView(this).apply{text=title;textSize=22f;setTextColor(Color.rgb(20,24,35));setTypeface(null,1)}
        head.addView(t,LinearLayout.LayoutParams(0,60,1f));box.addView(head)
        return box
    }
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(Color.WHITE)}
    private fun addSpace(box:LinearLayout,h:Int=12){box.addView(Space(this),LinearLayout.LayoutParams(1,h))}
    private fun text(v:String,size:Float=14f,bold:Boolean=false):TextView=TextView(this).apply{text=v;textSize=size;setTextColor(Color.rgb(70,75,88));if(bold)setTypeface(null,1);setPadding(0,4,0,4)}
    private fun button(v:String,color:Int=blue):Button=Button(this).apply{text=v;textSize=13f;setTextColor(Color.WHITE);setBackgroundColor(color);isAllCaps=false}
    private fun replace(v:View){content.removeAllViews();content.addView(v,FrameLayout.LayoutParams(-1,-1))}

    private fun showHome(){
        val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,20,18,10);setBackgroundColor(bg)}
        val brand=text("⚡ SwiftShare",27f,true).apply{setTextColor(blue)};b.addView(brand)
        addSpace(b,14)
        val hero=card();hero.setBackgroundColor(Color.rgb(19,47,91));hero.addView(text("SHARE FILES",12f,true).apply{setTextColor(Color.WHITE)})
        hero.addView(text("Fast. Secure. No Internet.",24f,true).apply{setTextColor(Color.WHITE)})
        hero.addView(text("Send photos, videos and documents to nearby devices.",13f).apply{setTextColor(Color.LTGRAY)})
        b.addView(hero);addSpace(b)
        val row=LinearLayout(this);val send=button("↑\nSEND",blue);val receive=button("↓\nRECEIVE",green)
        send.setOnClickListener{showSend()};receive.setOnClickListener{showReceive()}
        row.addView(send,LinearLayout.LayoutParams(0,82,1f));row.addView(Space(this),LinearLayout.LayoutParams(10,1));row.addView(receive,LinearLayout.LayoutParams(0,82,1f));b.addView(row)
        addSpace(b)
        b.addView(text("Recent Transfers",18f,true));b.addView(text("Vacation Photo.jpg   •   2.4 MB   •   Sent"))
        b.addView(text("Beach Video.mp4       •   52.6 MB  •   Received"))
        b.addView(text("Document.pdf          •   1.8 MB   •   Sent"))
        val ad=TextView(this).apply{text="Advertisement";gravity=Gravity.CENTER;backgroundColor=Color.rgb(235,237,242);setPadding(0,16,0,16)}
        b.addView(ad,LinearLayout.LayoutParams(-1,70))
        replace(ScrollView(this).apply{addView(b)})
    }

    private fun showSend(){
        val b=base("Send Files");val c=card();c.addView(text("${selectedUris.size} file(s) selected",18f,true))
        val choose=button("Choose files");choose.setOnClickListener{chooseFiles()};c.addView(choose);addSpace(b);b.addView(c)
        addSpace(b);b.addView(text("Nearby devices",18f,true))
        endpoints.forEach{(id,name)->val x=button("📱  $name");x.setOnClickListener{requestConnection(id)};b.addView(x);addSpace(b,6)}
        if(endpoints.isEmpty()) b.addView(text("No devices yet. Use Receive on the other phone and tap Find nearby devices."))
        val find=button("Find nearby devices");find.setOnClickListener{startDiscovery()};b.addView(find)
        replace(ScrollView(this).apply{addView(b)})
    }

    private fun showReceive(){
        val b=base("Receive Files");val c=card();c.gravity=Gravity.CENTER
        c.addView(text("↓",64f,true).apply{setTextColor(green);gravity=Gravity.CENTER})
        c.addView(text("Waiting for sender",20f,true).apply{gravity=Gravity.CENTER})
        c.addView(text("Make sure the sender is nearby and has selected files.",13f).apply{gravity=Gravity.CENTER})
        val adv=button("Make this phone discoverable",green);adv.setOnClickListener{startAdvertising()};c.addView(adv)
        addSpace(b);b.addView(c);addSpace(b);b.addView(text("Nearby senders",18f,true))
        if(endpoints.isEmpty()) b.addView(text("No sender found yet."))
        endpoints.forEach{(id,name)->val x=button("📱  $name");x.setOnClickListener{requestConnection(id)};b.addView(x);addSpace(b,6)}
        val scan=button("Scan for devices");scan.setOnClickListener{startDiscovery()};b.addView(scan)
        replace(ScrollView(this).apply{addView(b)})
    }

    private fun showFiles(){
        val b=base("My Files",false);b.addView(text("Images   Videos   Apps   Documents   Music",14f,true))
        addSpace(b);val c=card();c.addView(text("Internal Storage",17f,true));c.addView(text("23.4 GB / 64 GB used     36%"))
        addSpace(c,12);c.addView(text("Recent Files",17f,true))
        listOf("Screenshot.png  •  1.3 MB","My Project Proposal.pdf  •  2.2 MB","Travel Vlog.mp4  •  125.6 MB","Presentation.pptx  •  6.4 MB").forEach{c.addView(text("▣  $it"))}
        b.addView(c);replace(ScrollView(this).apply{addView(b)})
    }

    private fun showHistory(){
        val b=base("Transfer History",false);b.addView(text("All     Sent     Received",14f,true))
        addSpace(b);val c=card();listOf("↑  Beach Video.mp4   52.6 MB   12:30 PM","↓  Vacation Photos (12)   28.4 MB   11:45 AM","↑  Project proposal.pdf   2.2 MB   10:20 AM","↓  My Song.mp3   4.6 MB   09:15 AM","↑  Presentation.pptx   6.4 MB   Yesterday").forEach{c.addView(text(it,14f));addSpace(c,3)}
        b.addView(c);replace(ScrollView(this).apply{addView(b)})
    }

    private fun showSettings(){
        val b=base("Settings",false);val c=card()
        listOf("Device name     Android Device","Receive location     Downloads/SwiftShare","Theme     System Default","Language     English","Show notifications     ON","Vibrate on transfer     ON","Use mobile data     OFF","Help & Feedback     ›","Privacy Policy     ›").forEach{c.addView(text(it,15f));addSpace(c,4)}
        b.addView(c);replace(ScrollView(this).apply{addView(b)})
    }

    private fun showAbout(){
        val b=base("About SwiftShare");val c=card();c.gravity=Gravity.CENTER
        c.addView(text("⚡",58f,true).apply{setTextColor(blue);gravity=Gravity.CENTER})
        c.addView(text("SwiftShare",25f,true).apply{gravity=Gravity.CENTER})
        c.addView(text("Version 1.0.0\nFast • Secure • No Internet",14f).apply{gravity=Gravity.CENTER})
        c.addView(text("\nWhat's New\nRate SwiftShare\nShare SwiftShare\nPrivacy Policy\nTerms of Service",15f).apply{gravity=Gravity.CENTER})
        b.addView(c);replace(ScrollView(this).apply{addView(b)})
    }

    private fun chooseFiles(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)}
        startActivityForResult(i,2001)
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==2001&&c==RESULT_OK&&d!=null){selectedUris.clear();d.clipData?.let{for(i in 0 until it.itemCount)selectedUris+=it.getItemAt(i).uri}?:d.data?.let{selectedUris+=it};showSend()}}
    private fun startDiscovery(){Nearby.getConnectionsClient(this).startDiscovery(serviceId,discovery,DiscoveryOptions.Builder().setStrategy(strategy).build()).addOnSuccessListener{toast("Scanning…")}.addOnFailureListener{toast("Discovery failed")}}
    private fun startAdvertising(){Nearby.getConnectionsClient(this).startAdvertising("SwiftShare-${Build.MODEL}",serviceId,lifecycle,AdvertisingOptions.Builder().setStrategy(strategy).build()).addOnSuccessListener{toast("This phone is discoverable ✓")}.addOnFailureListener{toast("Advertising failed")}}
    private fun requestConnection(id:String){Nearby.getConnectionsClient(this).requestConnection("SwiftShare-${Build.MODEL}",id,lifecycle).addOnSuccessListener{toast("Connection requested…")}.addOnFailureListener{toast("Connection failed")}}
    private fun sendFiles(){val id=connectedEndpoint?:return;if(selectedUris.isEmpty())return;selectedUris.forEach{uri->val pfd=contentResolver.openFileDescriptor(uri,"r")?:return@forEach;val name=getName(uri)?:"swiftshare_file";Nearby.getConnectionsClient(this).sendPayload(id,Payload.fromBytes(name.toByteArray(StandardCharsets.UTF_8)));Nearby.getConnectionsClient(this).sendPayload(id,Payload.fromFile(pfd))};showProgress()}
    private fun showProgress(){val b=base("Transfer Progress");val c=card();c.addView(text("Sending to nearby device",18f,true));c.addView(text("${selectedUris.size} file(s) • Transfer in progress"));val p=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.max=100;p.progress=72;c.addView(p);c.addView(text("72%    •    25.6 MB/s"));selectedUris.forEach{c.addView(text("▣  ${getName(it)?:"File"}    ✓"))};val cancel=button("Cancel",Color.GRAY);cancel.setOnClickListener{Nearby.getConnectionsClient(this).stopAllEndpoints();showScreen("home")};c.addView(cancel);b.addView(c);replace(ScrollView(this).apply{addView(b)})}
    private fun getName(uri:Uri):String?{contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())return it.getString(0)};return null}
    private fun requestPermissions(){val p=mutableListOf<String>();if(Build.VERSION.SDK_INT>=31){p+=Manifest.permission.BLUETOOTH_SCAN;p+=Manifest.permission.BLUETOOTH_CONNECT;p+=Manifest.permission.BLUETOOTH_ADVERTISE};if(Build.VERSION.SDK_INT>=32)p+=Manifest.permission.NEARBY_WIFI_DEVICES;if(Build.VERSION.SDK_INT in 29..31)p+=Manifest.permission.ACCESS_FINE_LOCATION;if(Build.VERSION.SDK_INT<=28)p+=Manifest.permission.ACCESS_COARSE_LOCATION;val m=p.filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED};if(m.isNotEmpty())ActivityCompat.requestPermissions(this,m.toTypedArray(),1001)}
    private fun toast(s:String){runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}}
    override fun onDestroy(){Nearby.getConnectionsClient(this).stopAllEndpoints();super.onDestroy()}
}