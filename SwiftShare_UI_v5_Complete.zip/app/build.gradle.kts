plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.swiftshare.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.swiftshare.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "1.0.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    implementation("com.google.android.gms:play-services-ads:25.4.0")
}